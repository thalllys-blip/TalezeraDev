# Stories — óculos off road

Projeto Remotion editável da edição comercial, em 1080 × 1920, 30 fps e 44,8 segundos.

Execute `npm ci` e `npm run dev` para abrir o Remotion Studio. Selecione `Oculos-Stories`. `Oculos-Original` conserva a referência sem edição. Os textos possuem nós JSX separados e controles editáveis no Inspector.

Use `npm run check` para verificar o TypeScript. Exporte com `npm run render`. Neste ambiente Linux, acrescente `-- --browser-executable=/usr/bin/chromium`. O resultado vai para `out/oculos-offroad-stories.mp4`, em H.264/AAC, yuv420p e BT.709.

Em `src/Story.tsx`, cada trecho tem sua própria sequência. Os tempos de `Word` são relativos ao vídeo original: a sequência pai mantém a imagem, a voz e os destaques sincronizados quando é movida ou aparada. Os parâmetros `x`, `y`, `size`, `life`, `moveX` e `moveY` controlam posição, tamanho, duração da animação e acompanhamento breve do gesto.

`public/original.mp4` preserva o arquivo enviado. `public/voice-clean.wav` contém a voz com tratamento leve, sem música. As fontes estão incluídas em `public/fonts`, sem dependência de downloads na renderização. `docs/analysis.md`, `docs/captions-source.json` e `docs/edit-decision-list.json` registram a transcrição automática, os cortes e os destaques.

Fonte: 464 × 832, cerca de 45,52 segundos. A exportação em 1080 × 1920 amplia essa gravação e não recupera detalhes ausentes no original. As aproximações adicionais ficam até 113%. Não foram acrescentados preços, nomes de modelos incertos, trilha, efeitos sonoros, ícones ou logo.

Validação final: 1344 quadros decodificados, 44,8 s, H.264/AAC e MP4 com fast start. Comparação do áudio exportado com a linha do tempo prevista em cinco pontos: atraso medido de 0 ms. Prévia aberta e conferida no Studio com Chromium; nenhum erro da composição nos pontos revisados. O relatório está em `docs/export-validation.json`.
