import React from 'react';
import {AbsoluteFill, Easing, Interactive, interpolate, Series, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Audio, Video} from '@remotion/media';
import type {InteractivitySchema} from 'remotion';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const accent = '#FF7A24';

type WordProps = {children: string; x: number; y: number; size: number; life: number; moveX: number; moveY: number; style?: React.CSSProperties};
const WordInner: React.FC<WordProps> = ({children, x, y, size, life, moveX, moveY, style}) => {
  const frame = useCurrentFrame();
  return <Interactive.Div name={children} style={{
    position: 'absolute', left: x - 410, top: y, width: 820, textAlign: 'center',
    fontFamily: 'SportDisplay, sans-serif', fontWeight: 800, fontSize: size,
    lineHeight: 1.05, letterSpacing: -2, color: 'white', whiteSpace: 'pre-line',
    textShadow: '0 3px 14px rgba(0,0,0,0.8), 0 1px 3px rgba(0,0,0,0.7)',
    opacity: interpolate(frame, [0, 2, life - 4, life], [0.2, 1, 1, 0], clamp),
    scale: interpolate(frame, [0, life * 0.22, life * 0.42, life * 0.8, life], [0.87, 1.035, 1, 1.012, 1], {...clamp, easing: Easing.bezier(0.22,1,0.36,1)}),
    translate: interpolate(frame, [0, 6, life], ['0px 24px', '0px 0px', `${moveX}px ${moveY}px`], {...clamp, easing: Easing.bezier(0.22,1,0.36,1)}),
    ...style,
  }}>
    {children}
    <div style={{height: 6, width: 76, margin: '17px auto 0', backgroundColor: accent,
      scale: interpolate(frame, [0, 8], [0.15, 1], {...clamp, easing: Easing.bezier(0.22,1,0.36,1)}),
      transformOrigin: 'left center'}} />
  </Interactive.Div>;
};
const wordSchema = {
  children: {type: 'text-content', default: '', description: 'Palavra ou expressão falada'},
  x: {type: 'number', hiddenFromList: false, default: 540}, y: {type: 'number', hiddenFromList: false, default: 1180},
  size: {type: 'number', hiddenFromList: false, default: 92}, life: {type: 'number', hiddenFromList: false, default: 30},
  moveX: {type: 'number', hiddenFromList: false, default: 0}, moveY: {type: 'number', hiddenFromList: false, default: 0},
} as const satisfies InteractivitySchema;
export const Word = Interactive.withSchema({Component: WordInner, componentName: '<Word>', schema: wordSchema, wrapInSequence: true});

// Source times stay unchanged inside each clip, including overlays and zooms.
const Shot: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return <AbsoluteFill style={{overflow: 'hidden', backgroundColor: '#171717'}}>
    <Video name="Imagem original e aproximações" src={staticFile('original.mp4')} muted premountFor={fps} objectFit="cover" style={{
      width: '100%', height: '100%',
      transformOrigin: `${interpolate(frame / fps, [0,4,5,8,9,17,21,24,28,34,38,42,43,45.5], [85,74,85,82,50,50,52,60,48,55,50,50,70,72], clamp)}% ${interpolate(frame / fps, [0,4,8,9,17,21,24,28,34,38,42,43,45.5], [50,43,42,48,55,60,48,50,45,50,50,54,54], clamp)}%`,
      scale: interpolate(frame / fps,
        [0,2.4,3,4.7,5.3,6.2,7.1,7.6,8.5,9.2,10.8,11.5,12.4,13.1,14.4,16.5,17.5,18,19.74,20.6,21.1,22.5,23.88,24.8,25.8,27.72,28.6,29.5,30.2,32.2,33.3,35,36,37.5,38.3,39,40.3,41.62,42.4,43,43.92,45.5],
        [1,1,1.025,1.025,1,1.035,1.045,1.045,1,1,1.10,1.10,1.10,1.12,1.10,1.13,1.13,1,1.12,1.12,1.04,1.04,1.10,1.10,1.02,1.12,1.12,1.04,1.10,1.10,1.04,1.04,1.10,1.12,1.12,1.02,1.06,1.10,1.10,1.015,1.015,1.015],
        {...clamp, easing: Easing.bezier(0.45,0,0.55,1)}),
    }}/>
    <Audio name="Voz original — limpeza leve" src={staticFile('voice-clean.wav')} premountFor={fps}/>
    <Word name="Gancho" from={2.8 * fps} durationInFrames={Math.round(0.66 * fps)} premountFor={fps} x={520} y={1390} size={102} life={20} moveX={0} moveY={0}>SE LIGA</Word>
    <Word name="Promoção falada" from={6.6 * fps} durationInFrames={Math.round(0.67 * fps)} premountFor={fps} x={400} y={1430} size={72} life={20} moveX={-10} moveY={-12}>PROMOÇÃO BOA</Word>
    <Word name="Óculos" from={10.88 * fps} durationInFrames={Math.round(0.62 * fps)} premountFor={fps} x={540} y={1290} size={100} life={19} moveX={0} moveY={0}>ÓCULOS</Word>
    <Word name="Marcas" from={12.14 * fps} durationInFrames={Math.round(0.36 * fps)} premountFor={fps} x={540} y={1160} size={98} life={11} moveX={0} moveY={0}>MARCAS</Word>
    <Word name="Modelos" from={12.5 * fps} durationInFrames={Math.round(0.74 * fps)} premountFor={fps} x={495} y={1180} size={98} life={22} moveX={28} moveY={-16}>MODELOS</Word>
    <Word name="Cores — próximo ao gesto" from={13.24 * fps} durationInFrames={Math.round(0.7 * fps)} premountFor={fps} x={500} y={1120} size={104} life={21} moveX={-26} moveY={24}>CORES</Word>
    <Word name="Combinação" from={13.94 * fps} durationInFrames={Math.round(0.9 * fps)} premountFor={fps} x={540} y={1240} size={88} life={27} moveX={0} moveY={0}>COMBINAR</Word>
    <Word name="Personalização" from={16.64 * fps} durationInFrames={Math.round(1.53 * fps)} premountFor={fps} x={540} y={1200} size={71} life={46} moveX={0} moveY={0}>PERSONALIZOU</Word>
    <Word name="Lentes — acompanha o gesto" from={19.84 * fps} durationInFrames={Math.round(1.16 * fps)} premountFor={fps} x={490} y={1200} size={76} life={35} moveX={36} moveY={-28}>TROCA DE LENTE</Word>
    <Word name="Qualidade" from={27.72 * fps} durationInFrames={Math.round(1.75 * fps)} premountFor={fps} x={540} y={1200} size={94} life={53} moveX={0} moveY={0}>QUALIDADE</Word>
    <Word name="Óculos de qualidade" from={37.58 * fps} durationInFrames={Math.round(1.1 * fps)} premountFor={fps} x={540} y={1180} size={82} life={33} moveX={0} moveY={0}>{'ÓCULOS DE\nQUALIDADE'}</Word>
    <Word name="Convite — aproveita" from={41.82 * fps} durationInFrames={Math.round(0.95 * fps)} premountFor={fps} x={540} y={1210} size={98} life={29} moveX={0} moveY={0}>APROVEITA</Word>
    <Word name="Promoção" from={43.6 * fps} durationInFrames={Math.round(0.42 * fps)} premountFor={fps} x={350} y={1440} size={76} life={13} moveX={0} moveY={0}>PROMOÇÃO</Word>
    <Word name="Fechamento" from={44.02 * fps} durationInFrames={Math.round(1.04 * fps)} premountFor={fps} x={350} y={1440} size={76} life={31} moveX={0} moveY={0}>IMPERDÍVEL</Word>
    <Word name="Para você" from={45.06 * fps} durationInFrames={Math.round(0.44 * fps)} premountFor={fps} x={350} y={1440} size={90} life={13} moveX={0} moveY={0}>VOCÊ</Word>
  </AbsoluteFill>;
};

export const Story = () => {
  const {fps} = useVideoConfig();
  return <AbsoluteFill>
    <style>{`@font-face{font-family:SportDisplay;src:url('${staticFile('fonts/Display.ttf')}') format('truetype');font-weight:800;font-display:block;}`}</style>
    <Series>
      <Series.Sequence name="Abertura e gancho" durationInFrames={219} premountFor={fps}><Shot/></Series.Sequence>
      <Series.Sequence name="Modelos e cores" trimBefore={7.5 * fps} durationInFrames={323} premountFor={fps}><Shot/></Series.Sequence>
      <Series.Sequence name="Detalhes e qualidade" trimBefore={(548 / 30) * fps} durationInFrames={425} premountFor={fps}><Shot/></Series.Sequence>
      <Series.Sequence name="Variedade no expositor" trimBefore={32.8 * fps} durationInFrames={177} premountFor={fps}><Shot/></Series.Sequence>
      <Series.Sequence name="Convite final" trimBefore={(1165 / 30) * fps} durationInFrames={200} premountFor={fps}><Shot/></Series.Sequence>
    </Series>
  </AbsoluteFill>;
};
