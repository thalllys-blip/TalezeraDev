import {registerRoot, Composition, AbsoluteFill, OffthreadVideo, staticFile} from 'remotion';
import {Story} from './Story';

const Source = () => <AbsoluteFill style={{backgroundColor: '#101010'}}><OffthreadVideo src={staticFile('original.mp4')} style={{width:'100%',height:'100%',objectFit:'contain'}} /></AbsoluteFill>;
const Root = () => <>
  <Composition id="Oculos-Stories" component={Story} durationInFrames={1344} fps={30} width={1080} height={1920}/>
  <Composition id="Oculos-Original" component={Source} durationInFrames={1365} fps={30} width={1080} height={1920}/>
</>;
registerRoot(Root);
