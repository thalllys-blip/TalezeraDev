# Transcrição e decisões da edição

Transcrição automática em português com tempos na mídia original. Termos com reconhecimento incerto não viraram destaques. As palavras animadas foram selecionadas entre expressões reconhecidas com segurança; nenhum preço, característica ou nome de modelo foi acrescentado.

## Conteúdo identificado

- Abertura: saudação, campanha da loja e promoção mencionada na fala.
- Cerca de 8–17 s: óculos, marcas, modelos, cores e combinação com a moto.
- Cerca de 18–21 s: acessórios e troca de lente.
- Cerca de 22–38 s: variedade e qualidade; enumeração de marcas com alguns termos incertos.
- Cerca de 39–45 s: fechamento, “aproveita”, “promoção imperdível” e “você”.

## Trechos automáticos — consulte o JSON para confiança por palavra

0.00–5.18 s: Bom dia turma, povo amissuado de Deus, se liga na semana das crenças da BRMOTES, ainda não acabou,
5.28–10.00 s: não tá, é um mês inteiro de promoção boa. E essa aqui também vai para criança e para adulto.
10.16–14.84 s: Olha esse panedão de óculos aqui, todas as marcas, modelos e cores para combinar com o grafismo
14.84–20.80 s: da sua moto, o adesivo que você personalizou, pinlotos para você poder colocar, troca de lente.
21.76–27.48 s: É produto para você não ficar indeciso, meu filho, porque o gosto é aqui na BRMOTES,
27.48–36.84 s: a qualidade nem se fala. 100% de estrada, de hush, Alpine Star, Telvision, Cetador,
36.92–40.74 s: não é muito óculos de qualidade. E é isso aí galerinha, segue o produto de qualidade
40.74–45.30 s: aqui na BRMOTES e aproveita tá, mês inteiro de promoção imperdível para você.

## Ajustes

Saída de 44,8 s, em uma única parte. Removidos somente pequenos intervalos entre falas: 7,30–7,50 s; 32,43–32,80 s; 38,70–38,83 s. A fala não foi acelerada. Aproximações até 113%, evitando recorte extra no rosto. Textos brancos, sombra leve e um detalhe laranja. Sem trilha, efeitos sonoros ou logo adicionado. Voz original com filtro de graves abaixo de 65 Hz, redução de ruído de 4 dB e normalização com limite de pico.

Os tempos de captions-source.json permanecem relativos ao original, inclusive os intervalos cortados. Os tempos da saída estão em edit-decision-list.json.